<?php

require_once("classes/Database.php");

$connection = new Database();
$db = $connection -> connection();
var_dump($db);

$sth = $db-> query("SELECT * FROM user");
$sth->execute();
$result = $sth->fetch(PDO::FETCH_ASSOC);
print_r($result);


echo '<h1>Liste des Utilisateurs</h1>';
echo '<button>Ajouter un Utilisateur</button>';


//afficher la liste


  ?>